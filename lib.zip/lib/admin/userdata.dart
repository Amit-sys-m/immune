import 'package:flutter/material.dart';

class Users extends StatefulWidget {
  const Users({Key? key}) : super(key: key);

  @override
  State<Users> createState() => _UsersState();
}

class _UsersState extends State<Users> {
  @override
  Widget build(BuildContext context) {
    return Material(
      child: ListView(
        children: [
          Container(
            color: const Color(0xffEEEEEE),
            child: Padding(
              padding: const EdgeInsets.only(top: 20, left: 20, right: 20),
              child: Container(
                height: 90,
                child: Column(
                  children: const [
                    Text("Name: Amit Patel"),
                    Text("Address: At. Gholvira Manor Rd Palghar"),
                    Text("Vaccine: Polio"),
                    Text("Date: 02-03-2022")
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            color: const Color(0xffEEEEEE),
            child: Padding(
              padding: const EdgeInsets.only(top: 20, left: 20, right: 20),
              child: Container(
                height: 90,
                child: Column(
                  children: const [
                    Text("Name: Amit Patel"),
                    Text("Address: At. Gholvira Manor Rd Palghar"),
                    Text("Vaccine: Polio"),
                    Text("Date: 02-03-2022")
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            color: const Color(0xffEEEEEE),
            child: Padding(
              padding: const EdgeInsets.only(top: 20, left: 20, right: 20),
              child: Container(
                height: 90,
                child: Column(
                  children: const [
                    Text("Name: Amit Patel"),
                    Text("Address: At. Gholvira Manor Rd Palghar"),
                    Text("Vaccine: Polio"),
                    Text("Date: 02-03-2022")
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            color: const Color(0xffEEEEEE),
            child: Padding(
              padding: const EdgeInsets.only(top: 20, left: 20, right: 20),
              child: Container(
                height: 90,
                child: Column(
                  children: const [
                    Text("Name: Amit Patel"),
                    Text("Address: At. Gholvira Manor Rd Palghar"),
                    Text("Vaccine: Polio"),
                    Text("Date: 02-03-2022")
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
