class MyRoutes {
  static const mainroute = "/mainpage";
  static const registerroute = "/registerpage";
  static const signinroute = "/signinpage";
  static const genderroute = "/genderpage";
  static const verifyroute = "/verifypage";
  static const otproute = "/otppage";
  static const homeroute = "/otppage";
  static const firstroute = "/mainpage";
  static const inforoute = "/infppage";
}
