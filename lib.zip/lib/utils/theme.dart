import 'package:flutter/material.dart';

class MyTheme {
  static Color creamColor = const Color(0xff651FFF);
  static Color myColor = const Color(0xffF06292);
  static Color pgColor = const Color(0xfffff333);
}
