import 'package:flutter/material.dart';

class Mdhistory extends StatefulWidget {
  const Mdhistory({Key? key}) : super(key: key);

  @override
  _MdhistoryState createState() => _MdhistoryState();
}

class _MdhistoryState extends State<Mdhistory> {
  @override
  Widget build(BuildContext context) {
    return Material(
      child: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.teal[200],
            title: const Text(
              "Medical History",
              style: TextStyle(color: Colors.black),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.all(32.0),
            child: ListView(
              children: [
                GestureDetector(
                  child: SizedBox(
                    height: 90,
                    child: Card(
                      color: Colors.teal[200],
                      elevation: 3.0,
                      child: const Center(
                          child: Text(
                        "Add Data",
                        style: TextStyle(fontSize: 20),
                      )),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
